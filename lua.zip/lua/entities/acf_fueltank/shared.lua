ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"  
ENT.Author			= "fervidusletum"
 
ENT.Spawnable		= false
ENT.AdminSpawnable	= false



