ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"  
ENT.Author			= "Kafouille"
 
ENT.Spawnable		= false
ENT.AdminSpawnable	= false



