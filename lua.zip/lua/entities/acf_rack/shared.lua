-- shared.lua

ENT.Type        = "anim"
ENT.Base        = "base_gmodentity"
ENT.Author      = "Sestze"

ENT.Spawnable   = false
ENT.AdminSpawnable = false