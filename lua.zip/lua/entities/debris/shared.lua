 ENT.Type = "anim"  
 ENT.Base = "base_gmodentity"     
 ENT.PrintName		= "Debris"  
 ENT.Author			= "Kafouille"  
 ENT.Contact			= "Kafouille@gmail.com"  
 ENT.Purpose			= "Atmospheric"  
 ENT.Instructions	= "A clone of props killed during battle"  
 
ENT.Spawnable			= false
ENT.AdminSpawnable		= false

