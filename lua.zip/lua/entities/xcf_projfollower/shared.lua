DEFINE_BASECLASS("base_gmodentity")
ENT.PrintName 		= "XCF Projectile Follower"
ENT.Author 			= "Bubbus"
ENT.Contact 		= "splambob@googlemail.com"
ENT.Purpose		 	= "For testing serverside ballistics."
ENT.Instructions 	= "Spawn and use ENT:RegisterTo(bullet) to follow the bullet."
ENT.Category 		= "XCF"

ENT.Spawnable 		= false
ENT.AdminOnly		= false
ENT.AdminSpawnable = false