DEFINE_BASECLASS("base_gmodentity")
ENT.PrintName 		= "XCF Rocket"
ENT.Author 			= "Bubbus"
ENT.Contact 		= "splambob@googlemail.com"
ENT.Purpose		 	= "Because bullets aren't cool enough."
ENT.Instructions 	= "Point towards face for removal of face.  Point away from face for instant fake tan (then removal of face)."
ENT.Category 		= "XCF"

ENT.Spawnable 		= true
ENT.AdminOnly		= false
ENT.AdminSpawnable = false