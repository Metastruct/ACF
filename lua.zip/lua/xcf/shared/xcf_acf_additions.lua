
XCF = XCF or {}
XCF.Ents = XCF.Ents or {}

