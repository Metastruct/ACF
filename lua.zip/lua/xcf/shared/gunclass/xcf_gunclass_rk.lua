//TODO: sort out the details
//print("hi there")
local Rocket = {}
	Rocket.spread = 1
	Rocket.name = "Rocket"
	Rocket.muzzleflash = "50cal_muzzleflash_noscale"
	Rocket.rofmod = 0.9
	Rocket.soundNormal = "weapons/ACF_Gun/mg_fire4.wav"
	Rocket.sound = " "
	Rocket.soundDistance = " "
ACF.Classes.GunClass["RK"] = Rocket	