include('shared.lua')

SWEP.PrintName			= "ACF Rocket Launcher"
SWEP.DrawAmmo			= true
SWEP.DrawWeaponInfoBox	= true
SWEP.BounceWeaponIcon   = true