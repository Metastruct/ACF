include('shared.lua')

SWEP.PrintName			= "ACF Anti-Tank GL"
SWEP.DrawAmmo			= true
SWEP.DrawWeaponInfoBox	= true
SWEP.BounceWeaponIcon   = true